// To see this file in action, you may need to comment out the code in 
// file 2.15.ts as these are competing definitions.

//declare var $: any;

//$('#id').html('Hello World');
 