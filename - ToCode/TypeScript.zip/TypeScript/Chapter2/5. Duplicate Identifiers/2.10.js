// Please note, I have named the example in this file `DeviceMotionEventExample`
// because `DeviceMotionEvent` is in the lib.d.ts file.
