// The existing DeviceMotionEvent has all of its existing properties
// plus our additional motionDescription property
function handleMotionEvent(e) {
    var acceleration = e.acceleration;
    var description = e.motionDescription;
}
