var Listing2_8;
(function (Listing2_8) {
    window.onclick = function (event) {
        var button = event.button;
    };
})(Listing2_8 || (Listing2_8 = {}));
