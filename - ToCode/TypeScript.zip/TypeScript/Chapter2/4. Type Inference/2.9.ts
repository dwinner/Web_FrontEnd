module Listing2_9 {

    function example() {
        return null;
    }

    var widened = example();

}