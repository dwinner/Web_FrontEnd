var Listing2_9;
(function (Listing2_9) {
    function example() {
        return null;
    }

    var widened = example();
})(Listing2_9 || (Listing2_9 = {}));
