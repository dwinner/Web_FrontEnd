module Listing2_8 {

    window.onclick = function (event) {
        var button = event.button;
    };

}