var contentElement = document.querySelector('#content');

contentElement.innerHTML = '<span>Hello World</span>';
