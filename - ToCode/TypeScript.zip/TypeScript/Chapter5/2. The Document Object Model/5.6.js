// NodeList
var elementsNodeList = document.querySelectorAll('#content');

// Node
var e = elementsNodeList[0];

// HTMLDivElement
var f = elementsNodeList[0];

console.log('e: ' + e);
console.log('f: ' + f);
