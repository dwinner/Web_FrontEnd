// NodeListOf<HTMLDivElement>
var elementsTypedNodeList = document.getElementsByTagName('div');

// HTMLDivElement
var d = elementsTypedNodeList[0];

console.log('d: ' + d);
