var contentElement = <HTMLDivElement> document.querySelector('#content');

contentElement.innerHTML = '<span>Hello World</span>';
