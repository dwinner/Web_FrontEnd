﻿function index(req, res) {
    res.render('index', { title: 'Express' });
}
exports.index = index;
;
//# sourceMappingURL=index.js.map
