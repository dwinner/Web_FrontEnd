var elem = document.getElementById('example');

console.log(elem.classList);
