var type = 'Ring Tailed Lemur';

function Lemur() {
    console.log(type);
    var type = 'Ruffed Lemur';
}

Lemur();
