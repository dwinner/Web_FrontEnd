 {
    var name = 'Scope Example';
    console.log('A: ' + name);
}

// 'B: Scope Example'
console.log('B: ' + name);
