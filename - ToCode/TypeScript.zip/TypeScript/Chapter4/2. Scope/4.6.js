{
    // This only works where ECMAScript 6 is supported.
    let name = 'Scope Example';
    console.log('A: ' + name);
}

// 'B: undefined'
console.log('B: ' + name);
