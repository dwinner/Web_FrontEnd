import hello = require('./1.56');

hello('Mark'); // instead of hello.greet('Mark');
 