define(["require", "exports"], function(require, exports) {
    function greet(name) {
        console.log('Hello ' + name);
    }

    
    return greet;
});
