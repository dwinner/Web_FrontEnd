define(["require", "exports", './1.56'], function(require, exports, hello) {
    hello('Mark'); // instead of hello.greet('Mark');
});
