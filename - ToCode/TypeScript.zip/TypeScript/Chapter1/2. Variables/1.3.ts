module Listing1_3 {

    function addNumbers(a, b) {
        // missing var keyword
        //total = a + b;
        //return total;
    }

}