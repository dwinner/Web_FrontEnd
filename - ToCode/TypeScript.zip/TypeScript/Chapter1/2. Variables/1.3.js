var Listing1_3;
(function (Listing1_3) {
    function addNumbers(a, b) {
        // missing var keyword
        //total = a + b;
        //return total;
    }
})(Listing1_3 || (Listing1_3 = {}));
