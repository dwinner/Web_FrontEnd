var Listing1_48;
(function (Listing1_48) {
    var Display = (function () {
        function Display() {
        }
        return Display;
    })();

    var display = new Display();

    // false
    var hasName = 'name' in display;
})(Listing1_48 || (Listing1_48 = {}));
