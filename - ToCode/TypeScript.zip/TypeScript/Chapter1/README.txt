﻿Notes:

There are some deliberate compiler errors in the example code in the book, each deliberate error is preceded by a comment explaining the error.

To ensure these projects compile, all of these errors have been muted by commenting them out, but you can uncomment each one in turn to see the effect of the error.

Some examples have been wrapped in a module, named after the listing; for example module Listing1_1

These modules prevent different examples from interfering with each other, for example some examples are updated versions of a previous listing.