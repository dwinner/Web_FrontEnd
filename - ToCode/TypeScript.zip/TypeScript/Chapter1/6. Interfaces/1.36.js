var nodeList = document.getElementsByTagName('div');

nodeList.onclick = function (event) {
    alert('Clicked');
};
