var Listing1_62;
(function (Listing1_62) {
    var Personalisation = (function () {
        function Personalisation() {
        }
        Personalisation.greet = function (obj) {
            return 'Hello ' + obj.name;
        };
        return Personalisation;
    })();
})(Listing1_62 || (Listing1_62 = {}));
