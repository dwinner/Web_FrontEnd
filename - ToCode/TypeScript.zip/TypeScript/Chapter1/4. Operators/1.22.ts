module Listing1_22 {

    var message: string;
    var isValid = true;

    // Long-hand equivalent
    if (isValid) {
        message = 'Okay';
    } else {
        message = 'Failed';
    }

} 