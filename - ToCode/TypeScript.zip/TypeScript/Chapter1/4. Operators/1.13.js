var Listing1_13;
(function (Listing1_13) {
    var counter = 0;

    do {
        ++counter;
    } while(counter < 10);

    alert(counter); // 10
})(Listing1_13 || (Listing1_13 = {}));
