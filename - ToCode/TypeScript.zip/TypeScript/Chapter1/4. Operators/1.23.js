var Listing1_23;
(function (Listing1_23) {
    var isValid = true;

    // Conditional operator
    var message = isValid ? 'Okay' : 'Failed';
})(Listing1_23 || (Listing1_23 = {}));
