module Listing1_16 {

    var str: string = '5';

    // 5: number 
    var num = +str;

    // -5: number 
    var negative = -str;

} 