module Listing1_23 {

    var isValid = true;

    // Conditional operator
    var message = isValid ? 'Okay' : 'Failed';

} 