var Listing1_16;
(function (Listing1_16) {
    var str = '5';

    // 5: number
    var num = +str;

    // -5: number
    var negative = -str;
})(Listing1_16 || (Listing1_16 = {}));
