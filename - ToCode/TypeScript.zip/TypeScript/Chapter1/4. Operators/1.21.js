var Listing1_21;
(function (Listing1_21) {
    var caravan;

    if (caravan && caravan.rooms > 5) {
        //...
    }
})(Listing1_21 || (Listing1_21 = {}));
