var Listing1_22;
(function (Listing1_22) {
    var message;
    var isValid = true;

    // Long-hand equivalent
    if (isValid) {
        message = 'Okay';
    } else {
        message = 'Failed';
    }
})(Listing1_22 || (Listing1_22 = {}));
