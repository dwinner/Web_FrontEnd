module Listing1_13 {

    var counter = 0;

    do {
        ++counter;
    } while (counter < 10);

    alert(counter); // 10

} 