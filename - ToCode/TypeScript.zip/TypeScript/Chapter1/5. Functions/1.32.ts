module Listing1_32 {

    var makeName = (f: string, l: string) => ({ first: f, last: l });

} 