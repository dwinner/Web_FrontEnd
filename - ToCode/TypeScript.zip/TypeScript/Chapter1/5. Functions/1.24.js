var Listing1_24;
(function (Listing1_24) {
    function getAverage(a, b, c) {
        var total = a + b + c;
        var average = total / 3;
        return 'The average is ' + average;
    }

    var result = getAverage(4, 3, 8);
})(Listing1_24 || (Listing1_24 = {}));
