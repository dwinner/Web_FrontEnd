var Listing1_31;
(function (Listing1_31) {
    var addNumbers = function (a, b) {
        return a + b;
    };

    var addNumbers = function (a, b) {
        return a + b;
    };

    var addNumbers = function (a, b) {
        return a + b;
    };
})(Listing1_31 || (Listing1_31 = {}));
