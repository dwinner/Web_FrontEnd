var Listing1_32;
(function (Listing1_32) {
    var makeName = function (f, l) {
        return ({ first: f, last: l });
    };
})(Listing1_32 || (Listing1_32 = {}));
