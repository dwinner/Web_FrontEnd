var Listing1_30;
(function (Listing1_30) {
    var Example = (function () {
        function Example() {
        }
        Example.prototype.getElementsByTagName = function (name) {
            return document.getElementsByTagName(name);
        };
        return Example;
    })();
})(Listing1_30 || (Listing1_30 = {}));
