module Listing1_31 {

    var addNumbers = (a: number, b: number) => a + b;

    var addNumbers = (a: number, b: number) => {
        return a + b;
    }

    var addNumbers = function (a: number, b: number) {
        return a + b;
    }

}