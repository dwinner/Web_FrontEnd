var Listing1_4;
(function (Listing1_4) {
    var name = 'Steve';
})(Listing1_4 || (Listing1_4 = {}));
