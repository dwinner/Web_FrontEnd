module Listing1_4 {

    var name: string = 'Steve';

} 