var Listing1_6;
(function (Listing1_6) {
    var person = {
        name: 'Mark',
        heightInCentimeters: 183
    };
})(Listing1_6 || (Listing1_6 = {}));
