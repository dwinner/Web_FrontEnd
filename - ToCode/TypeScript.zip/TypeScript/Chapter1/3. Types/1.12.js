var Listing1_12;
(function (Listing1_12) {
    var name = 'Avenue Road';

    // Error: Cannot convert 'string' to 'number'
    //var bedrooms: number = <number> name;
    // Works
    var bedrooms = name;
})(Listing1_12 || (Listing1_12 = {}));
