module Listing1_6 {

    interface Person {
        name: string;
        heightInCentimeters: number;
    }

    var person: Person = {
        name: 'Mark',
        heightInCentimeters: 183
    }

}