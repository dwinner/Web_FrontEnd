var Listing1_11;
(function (Listing1_11) {
    var avenueRoad = {
        bedrooms: 11,
        bathrooms: 10,
        butlers: 1
    };

    // Errors: Cannot convert House to Mansion
    //var mansion: Mansion = avenueRoad;
    // Works
    var mansion = avenueRoad;
})(Listing1_11 || (Listing1_11 = {}));
