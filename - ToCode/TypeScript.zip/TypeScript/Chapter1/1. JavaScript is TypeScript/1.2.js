var Listing1_2;
(function (Listing1_2) {
    var radius = 4;
    var area = Math.PI * radius * radius;
})(Listing1_2 || (Listing1_2 = {}));
