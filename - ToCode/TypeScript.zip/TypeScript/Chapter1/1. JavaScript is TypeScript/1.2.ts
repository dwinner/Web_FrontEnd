module Listing1_2 {

    var radius = 4;
    var area = Math.PI * radius * radius;

} 