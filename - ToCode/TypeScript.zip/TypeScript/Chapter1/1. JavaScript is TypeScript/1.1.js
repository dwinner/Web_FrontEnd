var Listing1_1;
(function (Listing1_1) {
    // Not using with
    var radius = 4;
    var area = Math.PI * radius * radius;

    // Using with
    var radius = 4;
})(Listing1_1 || (Listing1_1 = {}));
