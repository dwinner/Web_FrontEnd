module Listing3_24 {

    class Acts {
        public static message = 'Acting';

        act() {
            alert(Acts.message);
        }
    }

}