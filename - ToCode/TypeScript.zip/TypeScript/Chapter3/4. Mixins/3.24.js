var Listing3_24;
(function (Listing3_24) {
    var Acts = (function () {
        function Acts() {
        }
        Acts.prototype.act = function () {
            alert(Acts.message);
        };
        Acts.message = 'Acting';
        return Acts;
    })();
})(Listing3_24 || (Listing3_24 = {}));
