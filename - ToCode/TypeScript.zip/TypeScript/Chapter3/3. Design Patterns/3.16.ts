interface ValetFactory {
    getWheelCleaning(): WheelCleaning;
    getBodyCleaning(): BodyCleaning;
}
 